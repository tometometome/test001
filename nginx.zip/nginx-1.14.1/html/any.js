
function anyCreateNewAnyObject() {

  var newAnyObject;
  var element;
  var jQuerySelectorString;
  
  if ( arguments.length === 0 ) {
  
    newAnyObject = {};

    newAnyObject.removeJavaScriptFromHead = function() {
    
      jQuery("head script").remove(); 
              
      return this;
    
    }

    newAnyObject.removeJavaScriptFromBody = function() {
    
      jQuery("body script").remove(); 
              
      return this;
    
    }

    newAnyObject.appendJavaScriptFileToHead = function(src) {
    
      var stringArray;
      
      stringArray = [];
      
      stringArray.push("<script ");
      stringArray.push("type=");
      stringArray.push("\"");
      stringArray.push("text/javascript");
      stringArray.push("\" ");      
      stringArray.push("src=");
      stringArray.push("\"");
      stringArray.push(src.toString());
      stringArray.push("\">");
      stringArray.push("</script>");
            
      jQuery("head").append(stringArray.join(""));

      return this;
    
    }

    newAnyObject.removeJavaScriptFileFromHead = function(src) {
    
      var stringArray;
      
      stringArray = [];
      
      stringArray.push("head script[src='");
      stringArray.push(src.toString());
      stringArray.push("']");
      
      jQuery(stringArray.join("")).remove();

      return this;
    
    }

    newAnyObject.removeJavaScriptFileFromBody = function(src) {
    
      var stringArray;
      
      stringArray = [];
      
      stringArray.push("body script[src='");
      stringArray.push(src.toString());
      stringArray.push("']");
      
      jQuery(stringArray.join("")).remove();

      return this;
    
    }
    
    newAnyObject.moveJavaScriptFileFromBodyToHead = function(src) {
    
      this.removeJavaScriptFileFromBody(src);
      this.appendJavaScriptFileToHead(src);

      return this;
    
    }    

    newAnyObject.appendCSSFileToHead = function(href) {
    
      var stringArray;
      
      stringArray = [];
      
      stringArray.push("<link ");
      stringArray.push("rel=");
      stringArray.push("\"");
      stringArray.push("stylesheet");
      stringArray.push("\" ");
      stringArray.push("type=");
      stringArray.push("\"");
      stringArray.push("text/css");
      stringArray.push("\" ");
      stringArray.push("href=");
      stringArray.push("\"");
      stringArray.push(href.toString());
      stringArray.push("\">");
      stringArray.push("</link>");
            
      jQuery("head").append(stringArray.join(""));

      return this;
    
    }

    newAnyObject.removeCSS = function() {
    
      jQuery("link[rel='stylesheet']").remove(); 
      jQuery("style").remove();  
      jQuery("[style]").removeAttr("style");
              
      return this;
    
    }

    newAnyObject.removeCSSFromHead = function() {
    
      jQuery("head link[rel='stylesheet']").remove(); 
      jQuery("head style").remove();  
      jQuery("head [style]").removeAttr("style");
              
      return this;
    
    }

    newAnyObject.removeCSSFromBody = function() {
    
      jQuery("body link[rel='stylesheet']").remove(); 
      jQuery("body style").remove();  
      jQuery("body [style]").removeAttr("style");
              
      return this;
    
    }

    newAnyObject.removeCSSFileFromHead = function(href) {
    
      var stringArray;
      
      stringArray = [];
      
      stringArray.push("head link");
      stringArray.push("[rel='stylesheet']");
      stringArray.push("[type='text/css']");
      stringArray.push("[href='");
      stringArray.push(href.toString());
      stringArray.push("']");
      
      jQuery(stringArray.join("")).remove();

      return this;
    
    }

    newAnyObject.removeCSSFileFromBody = function(href) {
    
      var stringArray;
      
      stringArray = [];
      
      stringArray.push("body link");
      stringArray.push("[rel='stylesheet']");
      stringArray.push("[type='text/css']");
      stringArray.push("[href='");
      stringArray.push(href.toString());
      stringArray.push("']");
      
      jQuery(stringArray.join("")).remove();

      return this;
    
    }

    newAnyObject.moveCSSFileFromBodyToHead = function(href) {
    
      this.removeCSSFileFromBody(href);
      this.appendCSSFileToHead(href);

      return this;
    
    }
           
  } else {
  
    jQuerySelectorString = arguments[0].toString();
  
    newAnyObject = {};
    newAnyObject.elementArray = [];

    jQuery(jQuerySelectorString).each(function(jQueryIndex, jQueryElement) {

      elementObject = {};
      elementObject.tagName = jQuery(jQueryElement).prop("tagName").toString().toLowerCase();
      elementObject.innerHTML = jQuery(jQueryElement).html();
      elementObject.outerHTMLBefore = "";
      elementObject.outerHTMLAfter = "";
  
      elementObject.attributeKeyValueArray = [];
                        
      jQuery(this).each(function() {
  
        jQuery.each(this.attributes, function() {
      
          attributeKeyValueObject = {};
        
          attributeKeyValueObject.key = "";
          attributeKeyValueObject.value = "";
    
          if ( this.specified ) {
  
            if ( typeof this.name !== "undefined" ) { 
            
              attributeKeyValueObject.key = this.name.toString().toLowerCase(); 
              
            }
            
            if ( typeof this.value !== "undefined" ) { 
            
              attributeKeyValueObject.value = this.value; 
              
            }
          
          }
    
          if ( attributeKeyValueObject.key.toString().length > 0 ) {
        
            elementObject.attributeKeyValueArray.push(attributeKeyValueObject);
        
          }
    
        });
  
      });; 

      newAnyObject.elementArray.push(elementObject);

    });

    newAnyObject.getNumberOfHits = function() {
    
      var numberOfHits;
      
      numberOfHits = this.elementArray.length;

      return numberOfHits;

    }

    newAnyObject.getElement = function(indexElement) {
    
      var elementObject;
      
      elementObject = {};
    
      if ( indexElement < this.elementArray.length ) {
      
        elementObject = this.elementArray[indexElement];
      
        elementObject.toString = function() {

          var i;
          var stringArray;
          var quotes;
          
          if ( arguments.length === 0 ) {
          
            quotes = "\"";
          
          } else {
          
            quotes = arguments[0].toString();
          
          }
  
          stringArray = [];
    
          stringArray.push(this.outerHTMLBefore);
     
          stringArray.push("<");
          stringArray.push(this.tagName);
   
          if ( this.attributeKeyValueArray.length > 0 ) {
      
            stringArray.push(" ");  
       
          }
    
          i = 0;
      
          while ( i < this.attributeKeyValueArray.length ) {
      
            stringArray.push(this.attributeKeyValueArray[i].key.toString().toLowerCase());
            stringArray.push("=");
            stringArray.push(quotes);
            stringArray.push(this.attributeKeyValueArray[i].value.toString());            
            stringArray.push(quotes);
                  
            i = i + 1;
      
            if ( i < this.attributeKeyValueArray.length ) {
        
              stringArray.push(" ");
        
            }
      
          }
    
          stringArray.push(">");
    
          stringArray.push(this.innerHTML);
      
          stringArray.push("</");
          stringArray.push(this.tagName);            
          stringArray.push(">");            

          stringArray.push(this.outerHTMLAfter);
                
          return stringArray.join("");
        
        }
        
        elementObject.getTagName = function() {
        
          return this.tagName.toString();
        
        }
        
        elementObject.getAttributeKeys = function() {
        
          var i;
          var attributeKeysArray;
          
          attributeKeysArray = [];
          i = 0;
          
          while ( i < this.attributeKeyValueArray.length ) {
        
            attributeKeysArray.push(this.attributeKeyValueArray[i].key.toString());
        
            i = i + 1;
        
          }
          
          return attributeKeysArray;
        
        }
        
        elementObject.getAttributeValue = function(key) {
        
          var i;
          var keyLowerCase;
          var attributeValue;
          
          attributeValue = "";
          keyLowerCase = key.toString().toLowerCase();
          i = 0;
          
          while ( i < this.attributeKeyValueArray.length ) {
        
            if ( this.attributeKeyValueArray[i].key.toString().toLowerCase() === keyLowerCase ) {
           
              attributeValue = this.attributeKeyValueArray[i].value.toString(); 
              
              i = this.attributeKeyValueArray;
             
            }
        
            i = i + 1;
        
          }
          
          return attributeValue;
             
        }

        elementObject.getAttributeKeysAndValues = function() {
        
          var i;
          var stringArray;
          var quotes;

          if ( arguments.length === 0 ) {
          
            quotes = "\"";
          
          } else {
          
            quotes = arguments[0].toString();
          
          }
                
          stringArray = [];       
          i = 0;
          
          while ( i < this.attributeKeyValueArray.length ) {
        
            stringArray.push(this.attributeKeyValueArray[i].key.toString().toLowerCase());
            stringArray.push("=");
            stringArray.push(quotes);            
            stringArray.push(this.attributeKeyValueArray[i].value.toString().toLowerCase());
            stringArray.push(quotes);

            i = i + 1;

            if ( i < this.attributeKeyValueArray.length ) {
            
              stringArray.push(" ");                    
            
            }
        
          }
          
          return stringArray.join("");
             
        }

        elementObject.getInnerHTML = function() {
        
          return this.innerHTML.toString();
        
        }            

        elementObject.getOuterHTMLBefore = function() {
        
          return this.outerHTMLBefore.toString();
        
        }            
      
        elementObject.getOuterHTMLAfter = function() {
        
          return this.outerHTMLAfter.toString();
        
        }            
      
      } 
      
      return elementObject;
    
    }

    newAnyObject.toString = function() {
  
      var i;
      var j;
      var stringArray;
      var quotes;

      if ( arguments.length === 0 ) {
          
        quotes = "\"";
          
      } else {
          
        quotes = arguments[0].toString();
          
      }
         
      stringArray = [];
      i = 0;
        
      while ( i < this.elementArray.length ) {
    
        stringArray.push(this.elementArray[i].outerHTMLBefore);
     
        stringArray.push("<");
        stringArray.push(this.elementArray[i].tagName);
      
        if ( this.elementArray[i].attributeKeyValueArray.length > 0 ) {
      
          stringArray.push(" ");  
       
        }
    
        j = 0;
      
        while ( j < this.elementArray[i].attributeKeyValueArray.length ) {
      
          stringArray.push(this.elementArray[i].attributeKeyValueArray[j].key.toString().toLowerCase());
          stringArray.push("=");
          stringArray.push(quotes);          
          stringArray.push(this.elementArray[i].attributeKeyValueArray[j].value.toString());            
          stringArray.push(quotes); 
      
          j = j + 1;
      
          if ( j < this.elementArray[i].attributeKeyValueArray.length ) {
        
            stringArray.push(" ");
        
          }
      
        }
    
        stringArray.push(">");
      
        stringArray.push(this.elementArray[i].innerHTML);
      
        stringArray.push("</");
        stringArray.push(this.elementArray[i].tagName);            
        stringArray.push(">");            

        stringArray.push(this.elementArray[i].outerHTMLAfter);
                
        i = i + 1;
    
      }
  
      return stringArray.join("");
  
    }

    newAnyObject.setInnerHTML = function(HTML) {
  
      var i;
  
      i = 0;
    
      while ( i < this.elementArray.length ) {
    
        this.elementArray[i].innerHTML = HTML.toString();
      
        i = i + 1;
    
      }
    
      return this;
          
    }
  
    newAnyObject.addInnerHTMLBeforeAndAfter = function(HTMLBefore, HTMLAfter) {
  
      var i;
  
      i = 0;
    
      while ( i < this.elementArray.length ) {
    
        this.elementArray[i].innerHTML = HTMLBefore.toString() + this.elementArray[i].innerHTML + HTMLAfter.toString();
      
        i = i + 1;
    
      }
    
      return this;
          
    }

    newAnyObject.setOuterHTMLBefore = function(HTML) {
  
      var i;
  
      i = 0;
    
      while ( i < this.elementArray.length ) {
    
        this.elementArray[i].outerHTMLBefore = HTML.toString();
      
        i = i + 1;
    
      }
    
      return this;
          
    }

    newAnyObject.setOuterHTMLAfter = function(HTML) {
  
      var i;
  
      i = 0;
    
      while ( i < this.elementArray.length ) {
    
        this.elementArray[i].outerHTMLAfter = HTML.toString();
      
        i = i + 1;
    
      }
    
      return this;
          
    }

    newAnyObject.addOuterHTMLBeforeAndAfter = function(HTMLBefore, HTMLAfter) {
  
      var i;
  
      i = 0;
    
      while ( i < this.elementArray.length ) {
    
        this.elementArray[i].outerHTMLBefore = HTMLBefore.toString() + this.elementArray[i].outerHTMLBefore;
        this.elementArray[i].outerHTMLAfter = this.elementArray[i].outerHTMLAfter + HTMLAfter.toString();            
      
        i = i + 1;
    
      }
    
      return this;
          
    }

    newAnyObject.addOuterHTMLBefore = function(HTMLBefore) {
    
      return this.addOuterHTMLBeforeAndAfter(HTMLBefore, "");
          
    }

    newAnyObject.addOuterHTMLAfter = function(HTMLAfter) {
    
      return this.addOuterHTMLBeforeAndAfter("", HTMLAfter);
          
    }

  }

  return newAnyObject;

}    
      
function any() {

  var newAnyObject;
  var jQuerySelectorString;

  if ( arguments.length === 0 ) {

    newAnyObject = anyCreateNewAnyObject(); 

  } else {
  
    jQuerySelectorString = arguments[0].toString();
  
    newAnyObject = anyCreateNewAnyObject(jQuerySelectorString);
  
  }
  
  return newAnyObject;

}

a = any;
anything = any;

